
public interface Transaction {
	
	 public int makeAPurchase();
	 public void inventory();
}
